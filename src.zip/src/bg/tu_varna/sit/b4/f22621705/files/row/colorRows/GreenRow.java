package bg.tu_varna.sit.b4.f22621705.files.row.colorRows;

import bg.tu_varna.sit.b4.f22621705.files.row.Pixel;
import bg.tu_varna.sit.b4.f22621705.files.row.Row;

import java.util.List;

public class GreenRow extends Row {
    @Override
    public List<Pixel> getPixelsList() {
        return super.getPixelsList();
    }

    @Override
    public void setPixelsList(List<Pixel> pixelsList) {
        super.setPixelsList(pixelsList);
    }
    /**
     *
     * @param pixels the pixel that has to be added in the list
     *               the method adds pixel in the list
     */
    @Override
    public void putInRow(Pixel pixels) {
        super.putInRow(pixels);
    }
}
