package bg.tu_varna.sit.b4.f22621705.files.NetpbmFiles.filesInterface;

public interface WidthNetpbm {
    int getWidth();
    void setWidth(int width);
}
