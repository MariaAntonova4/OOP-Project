package bg.tu_varna.sit.b4.f22621705.files.NetpbmFiles;

public class PixelException extends Exception{
    public PixelException(String message){super(message);}
}
