package bg.tu_varna.sit.b4.f22621705.menu.models.load.models.switchh;

public class SwitchException extends Exception{
    public SwitchException(String message){super(message);}
}
