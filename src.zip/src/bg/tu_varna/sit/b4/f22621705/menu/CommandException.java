package bg.tu_varna.sit.b4.f22621705.menu;

public class CommandException extends Exception{
    public CommandException(String message){super(message);}
}
