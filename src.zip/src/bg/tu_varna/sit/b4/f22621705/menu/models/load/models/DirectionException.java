package bg.tu_varna.sit.b4.f22621705.menu.models.load.models;

public class DirectionException extends Exception{
    public DirectionException(String message){super(message);}
}
